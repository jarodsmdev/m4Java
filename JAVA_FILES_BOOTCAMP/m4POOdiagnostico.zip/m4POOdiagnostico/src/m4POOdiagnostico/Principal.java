/**
 * @authors Valentina Saldías, Priscila Carrillo, Andrés Contreras, Kevin Moreno, Leonel Briones
 */
package m4POOdiagnostico;


public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Tablero tablero = new Tablero();
		tablero.crearCarros();
		//tablero.mostrarPlano();
		tablero.menu();
	}
	
	
}
