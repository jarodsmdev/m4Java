# Proyecto Diagnóstico FrontLine

Integrantes:

Valentina Saldías: https://github.com/mundenius
Priscila Carrillo: https://github.com/PriscilaCarrillo
Kevin Moreno: https://github.com/kmra00
Andrés Contreras: https://github.com/AndresSCP
Leonel Briones: https://github.com/jarodsmdev

Descripción:
Videojuego de lanzamientos de Huevos, el objetivo es eliminar 18 carros de 3 tipos dispersados al azar y cada tipo de carro tiene su propia longitud y sólo se mostrará las ubicaciones al finalizar el juego.

El lanzamiento de Huevos es de manera ilimitada y el usuario puede terminar el juego cuando desee.

Enlace al repositorio: https://github.com/jarodsmdev/m4Java/tree/master/JAVA_FILES_BOOTCAMP/m4POOdiagnostico/src/m4POOdiagnostico