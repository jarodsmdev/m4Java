
/**
 * @authors Valentina Saldías, Priscila Carrillo, Andrés Contreras, Kevin Moreno, Leonel Briones
 */package m4POOdiagnostico;

public class Trupalla extends Carro{

    int nivelArmadura;
    String chofer;

//CONSTRUCTOR

public Trupalla(){}

public int getNivelArmadura(){
    return nivelArmadura;
}
public void setNivelArmadura(int nivelArmadura){
    this.nivelArmadura = nivelArmadura;
}

public String getChofer(){
    return chofer;
}
public void setChofer(String chofer){
    this.chofer = chofer;
}


}
